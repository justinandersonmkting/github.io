// D3.js implementation for the influencer engagement chart
document.addEventListener("DOMContentLoaded", function () {
  // Influencer data - Using the real Dallas influencer data provided
  const influencerData = [
    {
      name: "krishphotos",
      category: "beauty",
      followers: 218300,
      preEngagement: 9.89,
      postEngagement: 12.36,
      preLikes: 20884,
      preComments: 703,
      postLikes: 26105,
      postComments: 879,
      roi: 896
    },
    {
      name: "macythemarketer_",
      category: "beauty",
      followers: 11100,
      preEngagement: 9.46,
      postEngagement: 11.83,
      preLikes: 931,
      preComments: 118,
      postLikes: 1164,
      postComments: 148,
      roi: 945
    },
    {
      name: "bakeupbeauty",
      category: "beauty",
      followers: 10000,
      preEngagement: 2.08,
      postEngagement: 2.6,
      preLikes: 196,
      preComments: 12,
      postLikes: 245,
      postComments: 15,
      roi: 520
    },
    {
      name: "vphenomenal",
      category: "beauty",
      followers: 108200,
      preEngagement: 1.67,
      postEngagement: 2.09,
      preLikes: 1760,
      preComments: 45,
      postLikes: 2200,
      postComments: 56,
      roi: 427
    },
    {
      name: "kerrently",
      category: "beauty",
      followers: 329200,
      preEngagement: 1.03,
      postEngagement: 1.29,
      preLikes: 3310,
      preComments: 75,
      postLikes: 4138,
      postComments: 94,
      roi: 215
    },
    {
      name: "sallybeauty",
      category: "beauty",
      followers: 655100,
      preEngagement: 0.08,
      postEngagement: 0.1,
      preLikes: 484,
      preComments: 44,
      postLikes: 605,
      postComments: 55,
      roi: 98
    }
  ];

  // Set up the D3 chart dimensions
  function createD3Chart(data) {
    // Clear any existing chart
    d3.select("#d3-chart").html("");

    // Define chart dimensions and margins
    const margin = { top: 40, right: 30, bottom: 90, left: 60 };
    const width =
      document.getElementById("d3-chart").clientWidth -
      margin.left -
      margin.right;
    const height = 400 - margin.top - margin.bottom;

    // Create SVG element
    const svg = d3
      .select("#d3-chart")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Define scales
    const x = d3
      .scaleBand()
      .domain(data.map((d) => d.name))
      .range([0, width])
      .padding(0.3);

    const y = d3
      .scaleLinear()
      .domain([
        0,
        d3.max(data, (d) => Math.max(d.preEngagement, d.postEngagement)) * 1.1
      ]) // Add 10% padding at top
      .range([height, 0]);

    // Create axes
    const xAxis = d3.axisBottom(x).tickSize(0);

    const yAxis = d3.axisLeft(y).tickFormat((d) => d + "%");

    // Add x-axis
    svg
      .append("g")
      .attr("class", "x-axis")
      .attr("transform", `translate(0,${height})`)
      .call(xAxis)
      .selectAll("text")
      .attr("transform", "translate(-10,0)rotate(-45)")
      .style("text-anchor", "end")
      .style("font-size", "12px");

    // Add y-axis
    svg.append("g").attr("class", "y-axis").call(yAxis);

    // Calculate the width of each individual bar
    const barWidth = x.bandwidth() / 2 - 2; // 2px gap between bars

    // Create group for pre-campaign bars
    const barGroupsPre = svg
      .selectAll(".bar-group-pre")
      .data(data)
      .enter()
      .append("g")
      .attr("class", "bar-group-pre")
      .attr("transform", (d) => `translate(${x(d.name)},0)`);

    // Add pre-campaign bars
    barGroupsPre
      .append("rect")
      .attr("class", "bar pre-bar")
      .attr("x", 0)
      .attr("width", barWidth)
      .attr("y", height)
      .attr("height", 0)
      .style("fill", "#0a1828")
      .transition()
      .duration(800)
      .attr("y", (d) => y(d.preEngagement))
      .attr("height", (d) => height - y(d.preEngagement));

    // Create group for post-campaign bars
    const barGroupsPost = svg
      .selectAll(".bar-group-post")
      .data(data)
      .enter()
      .append("g")
      .attr("class", "bar-group-post")
      .attr("transform", (d) => `translate(${x(d.name) + barWidth + 2},0)`);

    // Add post-campaign bars
    barGroupsPost
      .append("rect")
      .attr("class", "bar post-bar")
      .attr("x", 0)
      .attr("width", barWidth)
      .attr("y", height)
      .attr("height", 0)
      .style("fill", "#4dc0b5")
      .transition()
      .duration(800)
      .delay(400) // Slight delay for visual effect
      .attr("y", (d) => y(d.postEngagement))
      .attr("height", (d) => height - y(d.postEngagement));

    // Add tooltips
    const tooltip = d3
      .select("#d3-chart")
      .append("div")
      .attr("class", "d3-tooltip")
      .style("opacity", 0)
      .style("position", "absolute")
      .style("background-color", "rgba(0,0,0,0.85)")
      .style("color", "white")
      .style("padding", "10px")
      .style("border-radius", "5px")
      .style("pointer-events", "none")
      .style("font-size", "12px")
      .style("max-width", "200px");

    // Add tooltip event handlers to pre-campaign bars
    barGroupsPre
      .selectAll(".pre-bar")
      .on("mouseover", function (event, d) {
        tooltip.transition().duration(200).style("opacity", 0.9);
        tooltip
          .html(
            `
          <strong>${d.name}</strong><br>
          <span style="color: #0a1828">■</span> Pre-Campaign: ${
            d.preEngagement
          }%<br>
          Followers: ${numberWithCommas(d.followers)}<br>
          Avg. Likes: ${numberWithCommas(d.preLikes)}<br>
          Avg. Comments: ${numberWithCommas(d.preComments)}
        `
          )
          .style("left", event.pageX + 10 + "px")
          .style("top", event.pageY - 28 + "px");

        d3.select(this).style("opacity", 0.8);
      })
      .on("mouseout", function () {
        tooltip.transition().duration(500).style("opacity", 0);

        d3.select(this).style("opacity", 1);
      });

    // Add tooltip event handlers to post-campaign bars
    barGroupsPost
      .selectAll(".post-bar")
      .on("mouseover", function (event, d) {
        tooltip.transition().duration(200).style("opacity", 0.9);
        tooltip
          .html(
            `
          <strong>${d.name}</strong><br>
          <span style="color: #4dc0b5">■</span> Post-Campaign: ${
            d.postEngagement
          }%<br>
          Followers: ${numberWithCommas(d.followers)}<br>
          Avg. Likes: ${numberWithCommas(d.postLikes)}<br>
          Avg. Comments: ${numberWithCommas(d.postComments)}<br>
          Campaign ROI: ${d.roi}%
        `
          )
          .style("left", event.pageX + 10 + "px")
          .style("top", event.pageY - 28 + "px");

        d3.select(this).style("opacity", 0.8);
      })
      .on("mouseout", function () {
        tooltip.transition().duration(500).style("opacity", 0);

        d3.select(this).style("opacity", 1);
      });

    // Add chart title
    svg
      .append("text")
      .attr("x", width / 2)
      .attr("y", -10)
      .attr("text-anchor", "middle")
      .style("font-size", "16px")
      .style("font-weight", "600")
      .text("Influencer Engagement Rate Comparison");
  }

  // Helper function to format numbers with commas
  function numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
  }

  // Function to filter and sort data
  function filterAndSortData() {
    const categoryFilter = document.getElementById("category-filter").value;
    const sortFilter = document.getElementById("sort-filter").value;

    // Filter data based on category
    let filteredData = [...influencerData];

    if (categoryFilter !== "all") {
      filteredData = filteredData.filter(
        (item) => item.category === categoryFilter
      );
    }

    // Sort data based on selected option
    switch (sortFilter) {
      case "engagement":
        filteredData.sort((a, b) => b.preEngagement - a.preEngagement);
        break;
      case "followers":
        filteredData.sort((a, b) => b.followers - a.followers);
        break;
      case "roi":
        filteredData.sort((a, b) => b.roi - a.roi);
        break;
    }

    return filteredData;
  }

  // Function to update chart when filters change
  function updateChart() {
    const filteredData = filterAndSortData();
    createD3Chart(filteredData);

    // Also update visible influencer cards
    updateInfluencerCards(filteredData);
  }

  // Function to update visible influencer cards based on filters
  function updateInfluencerCards(filteredData) {
    const allCards = document.querySelectorAll(".influencer-card");
    const filteredNames = filteredData.map((item) => item.name);

    allCards.forEach((card) => {
      const cardName = card.querySelector("h3").textContent;

      if (filteredNames.includes(cardName)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  }

  // Add event listeners for filters
  document
    .getElementById("category-filter")
    .addEventListener("change", updateChart);
  document
    .getElementById("sort-filter")
    .addEventListener("change", updateChart);

  // Handle window resize for responsiveness
  window.addEventListener(
    "resize",
    debounce(function () {
      updateChart();
    }, 250)
  );

  // Debounce function to limit frequent executions on window resize
  function debounce(func, wait) {
    let timeout;
    return function () {
      const context = this;
      const args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(() => {
        func.apply(context, args);
      }, wait);
    };
  }

  // Form submission handling
  const leadForm = document.getElementById("lead-form");
  leadForm.addEventListener("submit", function (e) {
    e.preventDefault();

    // Get form values
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const business = document.getElementById("business").value;
    const industry = document.getElementById("industry").value;

    // You would typically send this to your server or email service
    // For demo purposes, we'll just show an alert
    alert(
      `Thank you ${name}! Your custom influencer analysis for ${business} will be sent to ${email} within 24 hours.`
    );

    // Clear the form
    leadForm.reset();

    // Analytics tracking placeholder
    if (typeof gtag === "function") {
      gtag("event", "form_submission", {
        event_category: "lead_generation",
        event_label: industry
      });
    }
  });

  // Initialize the chart with default filters
  updateChart();
});

// Add additional CSS to style D3 elements properly
document.addEventListener("DOMContentLoaded", function () {
  // Create a style element
  const style = document.createElement("style");

  // Add CSS rules for D3 chart
  style.textContent = `
    .d3-tooltip {
      z-index: 100;
      line-height: 1.5;
    }
    
    .x-axis path,
    .y-axis path {
      stroke: #ccc;
    }
    
    .x-axis line,
    .y-axis line {
      stroke: #eee;
    }
    
    .x-axis text,
    .y-axis text {
      fill: #666;
    }
    
    .bar {
      cursor: pointer;
      transition: opacity 0.2s ease;
    }
    
    .bar:hover {
      opacity: 0.8;
    }
    
    @media (max-width: 768px) {
      .x-axis text {
        font-size: 10px;
      }
      
      .y-axis text {
        font-size: 10px;
      }
    }
  `;

  // Append the style element to the head
  document.head.appendChild(style);
});
